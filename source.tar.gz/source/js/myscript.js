function muFun(obj){
                if(obj=="3"||obj==3){
                document.getElementById('TLID_DIV').style.display="block"; 
                return false;
                }else{
                document.getElementById('TLID_DIV').style.display="none"; 
                return false;
                }
        }
